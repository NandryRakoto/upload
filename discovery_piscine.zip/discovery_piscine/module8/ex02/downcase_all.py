#!/usr/bin/env python3
import sys

# Étape 1 : Définir la méthode qui transforme une chaîne
def downcase_it(texte):
    return texte.lower()

# Étape 2 : Vérifier s'il y a des paramètres
# On compte les arguments. S'il n'y a que le nom du fichier, la longueur est 1.
if len(sys.argv) == 1:
    print("none")
else:
    # Étape 3 : On boucle sur chaque paramètre (en ignorant le premier)
    for argument in sys.argv[1:]:
        resultat = downcase_it(argument)
        print(resultat)