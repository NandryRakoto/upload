# def shrink(chaine,str):
chaine="aghjjokijp"

for i in chaine[:8]:
     print(i)

        
