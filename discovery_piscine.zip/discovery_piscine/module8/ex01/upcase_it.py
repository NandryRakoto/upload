def upcase_it(text):
    print(text.upper())
    
upcase_it("coucou")
    
    