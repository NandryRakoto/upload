
nombre=int(input("Entrer un nombre inferieur a 25:"))
while (nombre <=25) :
    print(f"Inside the loop, my variable is:{nombre}")
    nombre+=1
if nombre >26:
    print("Error")

    