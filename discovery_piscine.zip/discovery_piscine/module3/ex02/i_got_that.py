phrase=input("What you gatta say?:")

while(phrase!="STOP"):
    phrase=input("I got that! Anything else? :")