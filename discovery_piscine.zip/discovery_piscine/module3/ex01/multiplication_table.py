nombre = int(input("Entrer un nombre positif:"))

for i in range(0,10):
   result=i*nombre

   print(f"{i}*{nombre}={result}")