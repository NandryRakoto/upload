#!/bin/env python3
import sys

if len(sys.argv)>1:
    maj=sys.argv[1]
    print(f"La repomse est:{maj.upper()}")
else:
    print("none")

