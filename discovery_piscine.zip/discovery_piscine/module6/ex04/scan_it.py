#!/bin/env python3
import sys
import re

reel = sys.argv[1:]
total = len(reel)
if total==2:
    arg1=sys.argv[1]
    arg2=sys.argv[2]

    resultat=re.findall(re.escape(arg1),arg2)
    
    print(len(resultat))

else :
    print("none")
