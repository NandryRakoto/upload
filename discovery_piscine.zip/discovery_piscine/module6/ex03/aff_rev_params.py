#!/bin/env python3
import sys


long=len(sys.argv[1:])

if  long >1:
    for i in range(long,0,-1):
      print(sys.argv[i])
else:
    print("none")   