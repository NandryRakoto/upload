#!/bin/env python3
import sys

if len(sys.argv)>1:
    min=sys.argv[1]
    print(f"La repomse est:{min.lower()}")
else:
    print("none")

