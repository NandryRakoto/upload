#!/usr/bin/env python3
import sys


if len(sys.argv) != 2:
    print("none")
else:
    
    reel = sys.argv[1]
   
    nb_Z = reel.count('z')
    
    
    if nb_Z > 0:
        print('z' * nb_Z)
    else:
        
        print("none")
    


