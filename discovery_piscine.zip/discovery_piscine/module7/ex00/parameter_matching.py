import sys

# reel=sys.argv[1:]
if len(sys.argv)>1:
    saisi=input("deviner le parametre :")
    param=sys.argv[1]
    if saisi == param:
        print("Bravo!")
    else:
        print("non desole")
else:
    print("none")

