#!/usr/bin/env python3
import sys


if len(sys.argv) != 3:
    print("none")
else:
    
    try:
        start = int(sys.argv[1])
        end = int(sys.argv[2])

       
        if start < end:
            
            resultat = list(range(start, end + 1))
            print(resultat)
        else:
            
            print("none")
            
    except ValueError:
        
        print("none")