import sys

reel = sys.argv[1:]

for var in reel:
    if len(var)>0:
        long=len(var)
        print(f"{var}:{long}")

    else:
        print("none")