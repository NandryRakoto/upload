age = int(input("Entrer votre age:"))

dixans = age+10
vingtans = age+20
trentans = age+30

print(f"You are currently {age} years old")
print(f"In 10 years, you'll be {dixans} years old.")
print(f"In 20 years, you'll be {vingtans} years old.")
print(f"In 30 years, you'll be {trentans} years old.")
