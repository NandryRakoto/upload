mot=input("give me a word:")
maj=mot.upper()
print(maj)