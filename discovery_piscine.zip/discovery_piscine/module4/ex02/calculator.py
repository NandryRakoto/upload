nombre1 = float(input("Entrer le premier nombre:"))
nombre2 = float(input("Entrer la deuxieme nombre nombre:"))





print(f"{nombre1}+{nombre2}={nombre1+nombre2}")
print(f"{nombre1}-{nombre2}={nombre1-nombre2}")
print(f"{nombre1}*{nombre2}={nombre1*nombre2}")
print(f"{nombre1}/{nombre2}={nombre1/nombre2}")
    
