chaine=input("Entrer les chaines:")
resultat=chaine.swapcase()

print(f"les chaines transforme :{resultat}")