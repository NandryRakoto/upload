import math
nombre=float(input("Give me a numbe:"))


resultat=math.ceil(nombre)
print(f"le nombre est:{resultat}")