nombre=float(input("Entrer un nombre:"))

if nombre.is_integer():
    print("C est un nombre entier ")
else:
    print("C est un nombre flotent")