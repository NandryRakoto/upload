tableau1=[2,5,-8,6,11,9,33,6,74,10]
tableau2=[]

for i in tableau1:
    j=i+2
    tableau2.append(j)
print(f"L'orifinal taleau{tableau1}")
print(f"Le nouveau tableau:{tableau2}")