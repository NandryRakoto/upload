tableau=[1,5,6,1,2,3,2]
print(f"Voici le tableau:{tableau}")