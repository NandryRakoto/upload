tableau1=[2,5,-8,6,11,9,33,6,74,10]
tableau2=[]
tableau3=[]

for i in tableau1:
    j=i+2
    tableau2.append(j)
print(f"L'orifinal taleau{tableau1}")
for k in tableau2:
    if k>5:
        tableau3.append(k)
print(f"le tableau ;odifier est:{tableau3}")
