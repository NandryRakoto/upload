tableau1=[2,74,-8,6,11,74,33,8,74,10]
tableau2=[]
tableau3=[]

for i in tableau1:
    j=i+2
    tableau2.append(j)
print(f"L'orifinal taleau{tableau1}")
for k in tableau2:
    if k>5:
        tableau3.append(k)
print(f"le tableau ;odifier est:{tableau3}")
tableauUnique=list(set(tableau3))

print(f"Voici le tableau sans doubblons:{{{', '.join(map(str, tableauUnique))}}}")
