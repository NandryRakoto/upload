prenom = input("Bonjour quelle est votre prenom:")
nom = input("et votre nom :")

print("Well, pleased to meet you," +prenom +" "+ nom)
