first_name = "Fanomezantsoa"
last_name = "ANDRIANOAVISON"

print(first_name +"  "+ last_name)
