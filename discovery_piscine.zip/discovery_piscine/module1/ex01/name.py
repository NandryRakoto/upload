first_name = "Fanomezantsoa"
last_name = "ANDRIANOAVISON"

whole_name = f"{first_name} {last_name}"
print(whole_name)