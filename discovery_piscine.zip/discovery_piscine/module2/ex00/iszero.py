nombre = int(input("entrer un nombre:"))

if nombre == 0:
    print("le nombre est egale a zero")
else :
    print("le nombre est differemt de zero")