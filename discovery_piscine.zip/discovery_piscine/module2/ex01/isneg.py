nombre = float(input("Entrer un nombre:"))

if nombre >0:
    print("Ce nombre est positif")
elif nombre ==0:
    print("Ce nombre est à la fois positif et négatif.")
else:
    print("Le nombre est negqtif")
