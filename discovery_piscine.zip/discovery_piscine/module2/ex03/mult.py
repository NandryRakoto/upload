nombre1=float(input("Entrer le premier nombre:"))
nombre2=float(input("Entrer le deuxieme nombe:"))

resultat= nombre1*nombre2

if resultat>0:
    print("le resultat est positif")
elif resultat<0:
    print("Le nombtre est negatif ")
else :
    print("le nombre est positif et negatif")
