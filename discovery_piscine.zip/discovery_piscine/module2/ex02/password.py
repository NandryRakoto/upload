password="Python is awesome"

motDepass = input("Entrer le mot de passe:")

if motDepass==password:
    print("Acces autoriser")

else :
    print("Acces refuser")